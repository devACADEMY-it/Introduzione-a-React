import React from 'react';
import './App.css';

function App() {
  return (
    <h1 className="my-title">Hello, world!</h1>
  );
}

export default App;
