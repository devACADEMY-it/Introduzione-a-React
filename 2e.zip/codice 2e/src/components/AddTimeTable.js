import React from 'react';

class AddTimeTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      city: '',
      offset: 0
    };

    this.handleCityChange = this.handleCityChange.bind(this);
    this.handleOffsetChange = this.handleOffsetChange.bind(this);
  }

  handleCityChange(event) {
    this.setState({
      city: event.target.value
    });
  }

  handleOffsetChange(event) {
    this.setState({
      offset: event.target.value
    });
  }

  render() {
    return (
      <form>
        <div className="field">
          <label className="label">Città</label>
          <div className="control">
            <input
              className="input"
              type="text"
              placeholder="es. Milano"
              value={this.state.city}
              onChange={this.handleCityChange}
            />
          </div>
        </div>

        <div className="field">
          <label className="label">Offset</label>
          <div className="control">
            <input
              className="input"
              type="number"
              placeholder="3"
              min="-8"
              max="8"
              step="1"
              value={this.state.offset}
              onChange={this.handleOffsetChange}
            />
          </div>
        </div>

        <button className="button is-primary" type="submit">Crea</button>
      </form>
    )
  }
}

export default AddTimeTable;