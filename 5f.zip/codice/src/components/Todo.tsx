import React from 'react';
import {ITodo} from '../App';

interface ITodoProps {
  data: ITodo,
  handleRemove: any
}

function Todo(props: ITodoProps) {
  const todo = props.data;

  return (
    <div className="column is-4">
      <div className="card">
        <header className="card-header">
          <p className="card-header-title">{todo.title}</p>
        </header>
        <div className="card-content">
          {todo.description}
          <br/>
          <small>Creato in data {new Date(todo.date).toLocaleDateString()}</small>
        </div>
        <footer className="card-footer">
          <a href="#/" className="card-footer-item" onClick={() => props.handleRemove(todo)}>Elimina</a>
        </footer>
      </div>
    </div>
  )
}

export default Todo;