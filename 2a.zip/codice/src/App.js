import React from 'react';
import './App.css';
import AppCard from './components/AppCard';

function App() {
  const users = [
    {
      name: 'Adriano',
      cell: '+39 13148249'
    },
    {
      name: 'Francesco',
      cell: '+39 13148249'
    },
    {
      name: 'Piero',
      cell: '+39 13148249'
    }
  ];

  return (
    <div className="section">
      <div className="columns">
        {
          users.map(user => <AppCard title={user.name} msg={user.cell} />)
        }
      </div>
    </div>
  );
}

export default App;
