import React from 'react';
import './App.css';
import TimeTable from "./components/TimeTable";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      timetables: [
        {
          id: 123,
          city: 'Roma',
          offset: 1
        },
        {
          id: 124,
          city: 'Mosca',
          offset: 3
        },
        {
          id: 125,
          city: 'Los Angeles',
          offset: -8
        }
      ],
      render: true
    };

    this.removeComponents = this.removeComponents.bind(this);
  }

  removeComponents() {
    this.setState({
      render: false
    })
  }

  render() {
    return (
      <div className="container is-fluid">
        <div className="section">
          <div className="columns">
            {
              this.state.render && this.state.timetables.map((timetable, idx) =>
                <TimeTable key={idx} city={timetable.city} offset={timetable.offset} />
              )
            }
          </div>
        </div>
        <button className="button is-primary" onClick={this.removeComponents}>Elimina componenti</button>
      </div>
    );
  }
}

export default App;
