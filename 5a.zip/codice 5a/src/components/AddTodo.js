import React from 'react';

function AddTodo(props) {
  return (
    <h1 className="title">AddTodo</h1>
)
}

export default AddTodo;