import React, { useContext } from 'react';
import SwitchThemeButton from "./SwitchThemeButton";
import {ThemeContext} from "./context";

function Navbar(props) {
  const theme = useContext(ThemeContext);

  const getNavbarClass = (theme) => {
    return theme === 'dark' ? 'is-dark' : 'is-white';
  };

  const getTitleClass = (theme) => {
    return theme === 'dark' ? 'has-text-white' : 'has-text-black';
  };

  return (
    <nav className={`navbar ${getNavbarClass(theme.value)}`} role="navigation" aria-label="main navigation">
      <div className="navbar-brand">
        <div className="navbar-item">
          <h1 className={`title ${getTitleClass(theme.value)}`}>TUDU' LIST</h1>
        </div>

        <button className="navbar-burger burger" aria-label="menu" aria-expanded="false"
                data-target="myNavbar">
          <span aria-hidden="true"></span>
          <span aria-hidden="true"></span>
          <span aria-hidden="true"></span>
        </button>
      </div>

      <div id="myNavbar" className="navbar-menu">
        <div className="navbar-end">
          <div className="navbar-item">
            <div className="buttons">
              <SwitchThemeButton />
            </div>
          </div>
        </div>
      </div>
    </nav>
  )
}

export default Navbar;