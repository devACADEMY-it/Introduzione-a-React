import React from 'react';

function Todo(props) {
  return (
    <h1 className="title">Todo</h1>
)
}

export default Todo;