import React, {SyntheticEvent, useState} from 'react';
import './App.css';
import Navbar from "./components/Navbar";
import TodoList from "./components/TodoList";
import AddTodo from "./components/AddTodo";
import {data} from "./data/todos";
import {ThemeContext} from "./components/context";

export interface ITodo {
  id: number
  title: string
  description: string
  date: Date
}

function App(props: any) {
  const [todos, setTodos] = useState(data as ITodo[]);
  const [newTodo, setNewTodo] = useState({
    id: data.length + 1,
    title: '',
    description: '',
    date: new Date()
  } as ITodo);
  const [theme, setTheme] = useState('light');

  const toggleTheme = () => {
    const newThemeValue = theme === 'dark' ? 'light' : 'dark';
    setTheme(newThemeValue);
  };

  const handleChange = (event: React.FormEvent<HTMLInputElement>) => {
    event.persist();

    const { name, value }: any = event.target;

    setNewTodo({
      ...newTodo,
      [name]: value
    });
  };

  const handleSubmit = (event: SyntheticEvent) => {
    event.preventDefault();

    setTodos([...todos, newTodo]);

    // Reimpostare il nuovo todo
    setNewTodo({
      ...newTodo,
      id: todos.length + 1,
      title: '',
      description: ''
    });
  };

  const handleRemove = (todo: ITodo) => {
    const newTodos = todos.filter((item: ITodo) => item.id !== todo.id);
    setTodos(newTodos);
  };

  return (
    <ThemeContext.Provider value={{ value: theme, update: toggleTheme } as any}>
      <Navbar />
      <section className={`section ${theme}`}>
        <TodoList
          data={todos}
          handleRemove={handleRemove}
        />
        <AddTodo
          data={newTodo}
          handleChange={handleChange}
          handleSubmit={handleSubmit}
        />
      </section>
    </ThemeContext.Provider>
  );
}

export default App;