import React from 'react';

function PostList(props) {
  return (
    <>
      <h1 className="subtitle">POSTS</h1>
      <ul>
        {
          props.data.map(post => <li key={post.id}>{post.title}</li>)
        }
      </ul>
    </>
  )
}

export default PostList;