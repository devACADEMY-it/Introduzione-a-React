import React from 'react';
import './App.css';
import Navbar from "./components/Navbar";
import TodoList from "./components/TodoList";
import AddTodo from "./components/AddTodo";
import {todos} from "./data/todos";

class App extends React.Component {
  constructor(props) {
    super(props);

    this.toggleTheme = () => {
      this.setState((prevState) => {
        const theme = {
          ...prevState.theme,
          value: prevState.theme.value === 'dark' ? 'light' : 'dark'
        };

        return {
          theme
        }
      })
    };

    this.state = {
      todos: todos,
      newTodo: {
        id: -1,
        title: '',
        description: '',
        date: new Date()
      },
      theme: {
        value: 'light',
        update: this.toggleTheme
      }
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    this.setState((prevState) => {
      const newTodo = {
        ...prevState.newTodo,
        [event.target.name]: event.target.value
      };

      return {
        newTodo
      }
    });
  }

  handleSubmit(event) {
    event.preventDefault();

    this.setState((prevState) => {
      const todos = [...prevState.todos, this.state.newTodo];

      return {
        todos
      }
    });
  }

  render() {
    return (
      <>
        <Navbar />
        <section>
          <TodoList
            data={this.state.todos}
          />
          <AddTodo
            data={this.state.newTodo}
            handleChange={this.handleChange}
            handleSubmit={this.handleSubmit}
          />
        </section>
      </>
    );
  }
}

export default App;