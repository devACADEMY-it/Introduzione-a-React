import React from 'react';

function App() {
  return (
    <h1>Ciao React</h1>
  );
}

export default App;
