import {useEffect, useState} from "react";

export const useFetchList = (baseUrl, currentPage) => {
  const [items, setItems] = useState([]);
  let newPage = currentPage;

  useEffect(() => {
    async function fetchUsers() {
      const url = `${baseUrl}&page=${currentPage}`;

      return await fetch(url).then(response => response.json());
    }

    fetchUsers().then(result => {
      const items = result.results;
      newPage = result.info.page;
      setItems(items);
    });
  }, [baseUrl, currentPage]);

  return { items, newPage };
};