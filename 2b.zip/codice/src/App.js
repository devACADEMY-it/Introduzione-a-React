import React from 'react';
import './App.css';
import TimeTable from "./components/TimeTable";

function App() {
  const timetables = [
    {
      city: 'Roma',
      offset: 1
    },
    {
      city: 'Mosca',
      offset: 3
    },
    {
      city: 'Los Angeles',
      offset: -8
    }
  ];

  return (
    <div className="container is-fluid">
      <div className="section">
        <div className="columns">
          {
            timetables.map(timetable => <TimeTable city={timetable.city} offset={timetable.offset} />)
          }
        </div>
      </div>
    </div>
  );
}

export default App;
