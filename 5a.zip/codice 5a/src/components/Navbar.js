import React from 'react';

function Navbar(props) {
  return (
    <h1 className="title">Navbar</h1>
  )
}

export default Navbar;