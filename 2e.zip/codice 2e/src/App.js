import React from 'react';
import './App.css';
import TimeTable from "./components/TimeTable";
import AddTimeTable from "./components/AddTimeTable";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      timetables: [
        {
          id: 123,
          city: 'Roma',
          offset: 1
        },
        {
          id: 124,
          city: 'Mosca',
          offset: 3
        },
        {
          id: 125,
          city: 'Los Angeles',
          offset: -8
        }
      ]
    };
  }

  handleSubmit(event) {
    // Aggiornare timetable
  }

  render() {
    return (
      <div className="container is-fluid">
        <div className="section">
          <div className="columns is-multiline">
            {
              this.state.timetables.map((timetable, idx) =>
                <TimeTable key={idx} city={timetable.city} offset={timetable.offset} />
              )
            }
          </div>
          <AddTimeTable
            handleSubmit={this.handleSubmit}
          />
        </div>
      </div>
    );
  }
}

export default App;
