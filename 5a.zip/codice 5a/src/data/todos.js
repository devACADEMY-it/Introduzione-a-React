export const todos = [
  {
    id: 1,
    date: new Date(),
    title: 'Todo 1',
    description: 'Fare Todo 1'
  },
  {
    id: 2,
    date: new Date(),
    title: 'Todo 2',
    description: 'Fare Todo 2',
  },
  {
    id: 3,
    date: new Date(),
    title: 'Todo 3',
    description: 'Fare Todo 3',
  },
];