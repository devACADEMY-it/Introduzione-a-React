import React from 'react';

function AppCard(props) {
  return (
    <div className="card">
      <header className="card-header">
        <h1 className="card-header-title subtitle">{ props.title }</h1>
      </header>
      <div className="card-content">
        <p>{ props.msg }</p>
      </div>
    </div>
  )
}

export default AppCard;