import React, { useState } from 'react';

function UserInput(props) {
  const [form, setForm] = useState({
    name: '',
    username: ''
  });

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value
    });
  };
  
  return (
    <form>
      <div className="field">
        <label className="label">Nome</label>
        <div className="control">
          <input
            className="input"
            type="text"
            name="name"
            placeholder="es. Adriano"
            value={form.name}
            onChange={handleChange}
          />
        </div>
      </div>

      <div className="field">
        <label className="label">Nickname</label>
        <div className="control">
          <input
            className="input"
            name="username"
            type="text"
            placeholder="es. carmhack"
            value={form.username}
            onChange={handleChange}
          />
        </div>
      </div>
    </form>
  )
}

export default UserInput;