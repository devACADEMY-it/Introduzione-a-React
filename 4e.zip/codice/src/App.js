import React from 'react';
import './App.css';
import Navbar from "./components/Navbar";
import UserList from "./components/UserList";

const ThemeContext = React.createContext('light');

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      theme: 'dark'
    };
  }

  render() {
    return (
      <div>
        <ThemeContext.Provider value={this.state.theme}>
          <Navbar />
          <div className="container is-fluid">
            <div className="section">
              <h1 className="title is-4">RANDOM USERS</h1>
              <UserList />
            </div>
          </div>

        </ThemeContext.Provider>
      </div>
    );
  }
}

export default App;