import React from 'react';

class AddTimeTable extends React.Component {
  render() {
    return (
      <form onSubmit={this.props.handleSubmit}>
        <div className="field">
          <label className="label">Città</label>
          <div className="control">
            <input
              className="input"
              type="text"
              placeholder="es. Milano"
              value={this.props.city}
              onChange={(e) => this.props.handleChange(e, 'city')}
            />
          </div>
        </div>

        <div className="field">
          <label className="label">Offset</label>
          <div className="control">
            <input
              className="input"
              type="number"
              placeholder="3"
              min="-8"
              max="8"
              step="1"
              value={this.props.offset}
              onChange={(e) => this.props.handleChange(e, 'offset')}
            />
          </div>
        </div>

        <button className="button is-primary" type="submit">Crea</button>
      </form>
    )
  }
}

export default AddTimeTable;