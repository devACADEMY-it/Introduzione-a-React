import React from 'react';
import './App.css';
import TimeTable from "./components/TimeTable";
import AddTimeTable from "./components/AddTimeTable";
import Navbar from "./components/Navbar";
import UserList from "./components/UserList";
import PostList from "./components/PostList";
import HOCList from "./components/HOCList";

const ThemeContext = React.createContext('light');
const Users = HOCList(UserList, 'https://jsonplaceholder.typicode.com/users');
const Posts = HOCList(PostList, 'https://jsonplaceholder.typicode.com/posts?_start=0&_limit=10');

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      theme: 'dark',
      timetables: [
        {
          id: 123,
          city: 'Roma',
          offset: 1
        },
        {
          id: 124,
          city: 'Mosca',
          offset: 3
        },
        {
          id: 125,
          city: 'Los Angeles',
          offset: -8
        }
      ],
      newTimeTable: {
        city: '',
        offset: 0
      },
      showModal: false
    };

    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.toggleModal = this.toggleModal.bind(this);
  }

  handleChange(event, prop) {
    const timeTable = { ...this.state.newTimeTable };
    timeTable[prop] = event.target.value;

    this.setState({
      newTimeTable: timeTable
    });
  }

  handleSubmit(event) {
    event.preventDefault();
    this.setState((state, props) => {
      return {
        timetables: [...state.timetables, state.newTimeTable]
      }
    })
  }

  toggleModal() {
    this.setState({
      showModal: !this.state.showModal
    })
  }

  render() {
    return (
      <div>
        <ThemeContext.Provider value={this.state.theme}>
          <Navbar />

          <div className="container is-fluid">
            <div className="section">
              <div className="columns is-multiline">
                {
                  this.state.timetables.map((timetable, idx) =>
                    <div className="column is-4">
                      <TimeTable key={idx} city={timetable.city} offset={timetable.offset} />
                    </div>
                  )
                }
              </div>
              <AddTimeTable
                city={this.state.newTimeTable.city}
                offset={this.state.newTimeTable.offset}
                handleChange={this.handleChange}
                handleSubmit={this.handleSubmit}
              />
            </div>
            <div className="columns">
              <div className="column">
                <Users />
              </div>
              <div className="column">
                <Posts />
              </div>
            </div>
          </div>
        </ThemeContext.Provider>
      </div>
    );
  }
}

export default App;