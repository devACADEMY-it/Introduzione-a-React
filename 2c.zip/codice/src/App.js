import React from 'react';
import './App.css';
import TimeTable from "./components/TimeTable";

function App() {
  const timetables = [
    {
      id: 123,
      city: 'Roma',
      offset: 1
    },
    {
      id: 124,
      city: 'Mosca',
      offset: 3
    },
    {
      id: 125,
      city: 'Los Angeles',
      offset: -8
    }
  ];

  return (
    <div className="container is-fluid">
      <div className="section">
        <div className="columns">
          {
            timetables.map((timetable, idx) => <TimeTable key={idx} city={timetable.city} offset={timetable.offset} />)
          }
        </div>
      </div>
    </div>
  );
}

export default App;
