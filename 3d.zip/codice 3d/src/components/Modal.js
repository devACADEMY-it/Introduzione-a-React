import React from 'react';
import ReactDOM from 'react-dom';

function Modal(props) {
  if (props.show) {
    return ReactDOM.createPortal(
      <div className="modal is-active">
        <div className="modal-background"></div>
        <div className="modal-content">
          <h1 className="title is-white">Ciao dalla modale</h1>
        </div>
        <button className="modal-close is-large" aria-label="close" onClick={props.toggleModal}></button>
      </div>,
      document.getElementById('modal')
    )
  } else {
    return null;
  }
}

export default Modal;