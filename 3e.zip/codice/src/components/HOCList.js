import React from 'react';

function HOCList(RenderComponent, url) {
  return class extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        items: []
      }
    }

    async componentDidMount() {
      const items = await fetch(url)
        .then(response => response.json())
        .then(result => result);

      this.setState((prevState, props) => {
        return {
          items
        }
      })
    }

    render() {
      return <RenderComponent data={this.state.items} />
    }
  }
}

export default HOCList;