import React, { useState, useEffect } from 'react';

const baseUrl = 'https://randomuser.me/api/?results=10&nat=gb&seed=devacademy';

function UserList(props) {
  const [items, setItems] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    async function fetchUsers() {
      const url = `${baseUrl}&page=${currentPage}`;

      return await fetch(url).then(response => response.json());
    }

    fetchUsers().then(result => {
      const items = result.results;
      const currentPage = result.info.page;
      setItems(items);
      setCurrentPage(currentPage);
    });
  }, [currentPage]);

  const getName = (name) => {
    return `${name.title} ${name.last} ${name.first}`;
  };

  const pageNext = () => {
    const newCurrentPage = currentPage + 1;
    setCurrentPage(newCurrentPage);
  };

  const pageBack = () => {
    const newCurrentPage = currentPage - 1;
    setCurrentPage(newCurrentPage);
  };

  return (
    <>
      <ul>
        {
          items.map(user => <li key={user.id.value}>{ getName(user.name) }</li>)
        }
      </ul>
      <hr/>
      <p>Pagina corrente: {currentPage}</p><br/>
      <div className="buttons">
        <button className="button is-info" onClick={pageBack}>Indietro</button>
        <button className="button is-info" onClick={pageNext}>Avanti</button>
      </div>
    </>
  )
}

export default UserList;