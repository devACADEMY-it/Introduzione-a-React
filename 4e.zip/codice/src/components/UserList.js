import React, { useState } from 'react';
import {useFetchList} from "../effects/fetchList";

const baseUrl = 'https://randomuser.me/api/?results=10&nat=gb&seed=devacademy';

function UserList(props) {
  const [currentPage, setCurrentPage] = useState(1);

  const { items, newPage } = useFetchList(baseUrl, currentPage);

  if (newPage !== currentPage) {
    setCurrentPage(newPage);
  }

  const getName = (name) => {
    return `${name.title} ${name.last} ${name.first}`;
  };

  const pageNext = () => {
    const newCurrentPage = currentPage + 1;
    setCurrentPage(newCurrentPage);
  };

  const pageBack = () => {
    const newCurrentPage = currentPage - 1;
    setCurrentPage(newCurrentPage);
  };

  return (
    <>
      <ul>
        {
          items.map(user => <li key={user.id.value}>{ getName(user.name) }</li>)
        }
      </ul>
      <hr/>
      <p>Pagina corrente: {currentPage}</p><br/>
      <div className="buttons">
        <button className="button is-info" onClick={pageBack}>Indietro</button>
        <button className="button is-info" onClick={pageNext}>Avanti</button>
      </div>
    </>
  )
}

export default UserList;